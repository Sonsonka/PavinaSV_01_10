﻿using PavinaSV_01_10.Classes;

//создание экземпляра базового класса
Product product = new("Пирожок с вишней", 25.3, 97.7);
//вывод информации об экземпляре базового класса в консоль
Console.WriteLine(product.WriteProduct());

//создание экземпляра класса потомка
ProductChild prodch = new("Пирожок с вишней", 25.3, 97.7, 210);
//вывод информации об экземпляре класса потомка в консоль
Console.WriteLine(prodch.WriteProduct());
