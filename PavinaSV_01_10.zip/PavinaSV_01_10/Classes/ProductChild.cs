﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PavinaSV_01_10.Classes
{
    //класс потомок
    public class ProductChild :Product //наследование от базового класса
    {
        //приватное поле калорийности продукта
        private int p;
        //конструктор класса потомка
        public ProductChild (string Name, double Belok, double Uglevod, int P) : base(Name, Belok, Uglevod)
        {
            this.p = P;
        }
        //свойство класса потомка с калорийностью продукта
        public int P
        {
            get { return p; }
            set { p = value; }
        }
        //переопределение функции качества базового класса
        public override double Quality ()
        {
            if (P > 0 && Uglevod > 0 && Belok > 0)
            {
                return base.Quality() * 1.2 + P * 7;
            } else
                return 0.0;
            return base.Quality();
        }
    }
}
