﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PavinaSV_01_10.Classes
{
    //объявление базового класса
    public class Product
    {
        //объявление приватных полей
        private string name; //имя
        private double belok; //количество белка
        private double uglevod; //количество углеводов
        //конструктор класса
        public Product (string Name, double Belok, double Uglevod)
        {
            this.name = Name;
            this.belok = Belok;
            this.uglevod = Uglevod;
        }
        //свойство базового класса с именем продукта
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        //свойство базового класса с количеством белка продукта
        public double Belok
        {
            get { return belok; }
            set { belok = value; }
        }
        //свойство базового класса с количеством углеводов продукта
        public double Uglevod
        {
            get { return uglevod; }
            set { uglevod = value; }
        }
        //функция, вычисляющая качество Q
        public virtual double Quality ()
        {
            if (Belok > 0 && Uglevod > 0)
            {
                return Uglevod * 4 + Belok * 4;
            } else
                return 0;
        }
        //функция для вывода информации о продукте
        public string WriteProduct ()
        {
            return $"Название продукта: {name}\nКоличество белка: {belok} г.\nКоличество углеводов: {uglevod} г.\nКачество: {Quality()}";
        }
    }
}
