using PavinaSV_01_10.Classes;

namespace TestsExam_01_10
{
    [TestClass]
    public class ProductTests
    {
        [TestMethod]
        public void TestQualityBaseTrue ()
        {
            Product product = new("������", 7, 15);
            double expected = 88.0;
            double actual = product.Quality();
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void TestQualityBaseFalse ()
        {
            Product product = new("������", 0, 15);
            double expected = 0.0;
            double actual = product.Quality();
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void TestQualityChildTrue ()
        {
            ProductChild prodch = new("������� � ������", 25.3, 97.7, 210);
            double expected = 2060.4;
            double actual = prodch.Quality();
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void TestQualityChildFalse ()
        {
            ProductChild prodch = new("������� � ������", 25.3, 0, 210);
            double expected = 0.0;
            double actual = prodch.Quality();
            Assert.AreEqual(expected, actual);
        }
    }
}